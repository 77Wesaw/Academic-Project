#include <iostream>
#include <vector>
#include "main.h"
#include "csv.h"
#include "Force.h"
#include "SerialPort.h"
#include "Modbus.h"
using namespace std;

Force::Force() 
{
	
    if (!this->modbus.connect(StressPortName))
    {
        std::cerr << "Failed to connect to " << StressPortName << std::endl;
    }
    else
    {
        std::cout << "Starting stress data acquisition..." << std::endl;
        std::cout << "Press Ctrl+C to exit" << std::endl << std::endl;
    }
}

Force::~Force() 
{
    this->modbus.disconnect();
}

//��ȡӦ��Ƭѹ��
float Force::readStress()
{
    return this->modbus.readStressValue();
}

//����ӳ������
void Force::processData(float force)
{

    FloatUnion forceFrame;
    forceFrame.floatValue = force;

    uint8_t hexFrame_force[6];
    hexFrame_force[0] = FrameHeader;
    hexFrame_force[5] = FrameFooter;

    hexFrame_force[1] = forceFrame.hexData[0];
    hexFrame_force[2] = forceFrame.hexData[1];
    hexFrame_force[3] = forceFrame.hexData[2];
    hexFrame_force[4] = forceFrame.hexData[3];

    this->MSContent = { hexFrame_force[0],hexFrame_force[1],hexFrame_force[2],
                hexFrame_force[3],hexFrame_force[4],hexFrame_force[5] };
}

void Force::createCsvHeader()
{
    this->forceFile.Header({ "Index","Stress (N)" });
}

