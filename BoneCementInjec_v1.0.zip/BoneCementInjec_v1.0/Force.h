#pragma once
#include <iostream>
#include <windows.h>
#include <vector>
#include "Modbus.h"
#include "main.h"
#include "csv.h"
using namespace std;

class Force
{
public:
    Force();

    ~Force();

    float readStress();

    void processData(float force);

    void createCsvHeader();

    ModbusClient modbus;

    //�����master�������ص�����
    std::vector<uint8_t> MSContent;

    CsvFile forceFile;
};