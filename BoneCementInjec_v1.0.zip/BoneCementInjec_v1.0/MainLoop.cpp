﻿#include <iostream>
#include <string>
#include <iomanip>
#include <thread>
#include "Force.h"
#include "SerialPort.h"
#include "Modbus.h"
#include "csv.h"
#include "Master.h"
#include "Slave.h"
#include "main.h"

int main() 
{
    Master master;
    Slave slave;
    Force force;

    /********************************打印&发送master编码器数值***************************************/
    //while (true)
    //{
    //    master.printEncoderData();//在电脑上打印编码器数值
    //}
    /******************************************************************************************/

    /*********************************应变片与master通信********************************************************/
    
    ////创建应变片力数据的csv表头
    //force.createCsvHeader();
    ////创建csv索引
    //int index = 1;
    //while (true) 
    //{
    //    float stress = force.readStress();
    //    float forceData = stress * K_Force_Mapping;

    //    //启动力矩数据帧编码
    //    force.processData(forceData);

    //    //往master发送力矩数据
    //   if (!MasterPort.send(force.MSContent))
    //    {
    //        cout << "Failed to send force to Master port" << endl;
    //    }

    //    // 写入csv文件的容器
    //    std::vector<std::string> content = { std::to_string(index),std::to_string(stress)};
    //    force.forceFile.Write(content);

    //    if (stress != -999.999) 
    //    {
    //        std::cout << "Stress: " << std::fixed << std::setprecision(3) << stress << " N" << std::endl;
    //    }
    //    else 
    //    {
    //        std::cout << "Error reading stress value" << std::endl;
    //    }
    //    //应变片的读取频率还不清楚，这是AD模块与电脑数据交互的频率
    //    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    //    index++;
    //    }
    /***********************************************************************************************************/
    
    /*********************************master与slave通信********************************************************/
    uint8_t hexFrame_angle[4];
    while (true)
    {
        master.receiveMasterData();
        hexFrame_angle[0] = master.masterFrame.hexData[0];
        hexFrame_angle[1] = master.masterFrame.hexData[1];
        hexFrame_angle[2] = master.masterFrame.hexData[2];
        hexFrame_angle[3] = master.masterFrame.hexData[3];

        slave.handleMasterData(hexFrame_angle, 4);
    }
    /***********************************************************************************************************/
    
    return 0;
}
