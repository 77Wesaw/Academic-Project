#include <iostream>
#include <vector>
#include "main.h"
#include "Master.h"

using namespace std;

Master::Master()
{

    //��Master�˿�
    if (!MasterPort.open(MasterPortName, 115200, 0, 8, 1))
    {
        cout << "Failed to Open Master Port" << endl;
    }
    else
    {
        cout << "Master Port Open Successfully!" << endl;
    }
}
Master::~Master() 
{

}

void Master::receiveMasterData()
{
    vector<uint8_t> MstRecvContent(6);

    int bytesRead = MasterPort.receive(MstRecvContent.data(), MstRecvContent.size());

    //����Ƿ������һ֡
    if (bytesRead == 6)
    {
        //���֡ͷ��֡β
        if (MstRecvContent[0] == FrameHeader && MstRecvContent[5] == FrameFooter)
        {
            //��������֡
            this->masterFrame.hexData[0] = MstRecvContent[1];
            this->masterFrame.hexData[1] = MstRecvContent[2];
            this->masterFrame.hexData[2] = MstRecvContent[3];
            this->masterFrame.hexData[3] = MstRecvContent[4];
        }
    }
}

void Master::printEncoderData()
{
    vector<uint8_t> MstRecvContent(6);

    int bytesRead = MasterPort.receive(MstRecvContent.data(), MstRecvContent.size());

    //����Ƿ������һ֡
    if (bytesRead == 6)
    {
        //���֡ͷ��֡β
        if (MstRecvContent[0] == FrameHeader && MstRecvContent[5] == FrameFooter)
        {
            //��������֡
            this->printFrame.hexData[0] = MstRecvContent[1];
            this->printFrame.hexData[1] = MstRecvContent[2];
            this->printFrame.hexData[2] = MstRecvContent[3];
            this->printFrame.hexData[3] = MstRecvContent[4];

            //��ӡ����֡
            cout << "Master Encoder data : " << this->printFrame.floatValue << std::endl;
        }
    }
}
