#include <iostream>
#include <windows.h>  // Windows����ͨ��
#include <string>
#include <vector>
#include <cstdint>
#include <iomanip>
#include "Modbus.h"


bool ModbusClient::connect(const std::string& portName, int baudRate)
{
    // ����COM�˿���
    std::string fullPortName = "\\\\.\\" + portName;

    // �򿪴���
    hSerial = CreateFileA(
        fullPortName.c_str(),
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );

    if (hSerial == INVALID_HANDLE_VALUE) {
        std::cerr << "Error: Could not open serial port " << portName << std::endl;
        return false;
    }

    // ���ô��ڲ���
    DCB dcbSerialParams = { 0 };
    dcbSerialParams.DCBlength = sizeof(dcbSerialParams);

    if (!GetCommState(hSerial, &dcbSerialParams)) {
        std::cerr << "Error: Could not get serial port state" << std::endl;
        CloseHandle(hSerial);
        hSerial = INVALID_HANDLE_VALUE;
        return false;
    }

    // ���ô��ڲ���: ������, 8����λ, 1ֹͣλ, ��У��
    dcbSerialParams.BaudRate = baudRate;
    dcbSerialParams.ByteSize = 8;
    dcbSerialParams.StopBits = ONESTOPBIT;
    dcbSerialParams.Parity = NOPARITY;

    if (!SetCommState(hSerial, &dcbSerialParams)) {
        std::cerr << "Error: Could not set serial port parameters" << std::endl;
        CloseHandle(hSerial);
        hSerial = INVALID_HANDLE_VALUE;
        return false;
    }

    // ���ó�ʱ
    COMMTIMEOUTS timeouts = { 0 };
    timeouts.ReadIntervalTimeout = 50;
    timeouts.ReadTotalTimeoutConstant = 500;
    timeouts.ReadTotalTimeoutMultiplier = 10;
    timeouts.WriteTotalTimeoutConstant = 500;
    timeouts.WriteTotalTimeoutMultiplier = 10;

    if (!SetCommTimeouts(hSerial, &timeouts)) {
        std::cerr << "Error: Could not set serial port timeouts" << std::endl;
        CloseHandle(hSerial);
        hSerial = INVALID_HANDLE_VALUE;
        return false;
    }

    connected = true;
    std::cout << "Successfully connected to " << portName << std::endl;
    return true;
}

void ModbusClient::disconnect()
{
    if (hSerial != INVALID_HANDLE_VALUE) {
        CloseHandle(hSerial);
        hSerial = INVALID_HANDLE_VALUE;
        connected = false;
        std::cout << "Serial port disconnected" << std::endl;
    }
}

bool ModbusClient::isConnected() const
{
    return connected;
}

// ����CRC16У����(Modbus RTU)
uint16_t ModbusClient::calculateCRC(const std::vector<uint8_t>& message) {
    uint16_t crc = 0xFFFF;

    for (size_t pos = 0; pos < message.size(); pos++) {
        crc ^= static_cast<uint16_t>(message[pos]);

        for (int i = 8; i != 0; i--) {
            if ((crc & 0x0001) != 0) {
                crc >>= 1;
                crc ^= 0xA001;
            }
            else {
                crc >>= 1;
            }
        }
    }

    return crc;
}

// ����CRC����Ϣ
std::vector<uint8_t> ModbusClient::addCRC(const std::vector<uint8_t>& message)
{
    std::vector<uint8_t> messageWithCRC = message;
    uint16_t crc = calculateCRC(message);

    // ����CRC (���ֽ���ǰ)
    messageWithCRC.push_back(crc & 0xFF);         // CRC���ֽ�
    messageWithCRC.push_back((crc >> 8) & 0xFF);  // CRC���ֽ�

    return messageWithCRC;
}

//��ӡ16��������
void ModbusClient::printHex(const std::vector<uint8_t>& data, const std::string& label) {
    if (!label.empty()) {
        std::cout << label << ": ";
    }

    for (const auto& byte : data) {
        std::cout << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(byte) << " ";
    }
    std::cout << std::dec << std::endl;
}

// ����Modbus���󲢽�����Ӧ
std::vector<uint8_t> ModbusClient::sendModbusRequest(const std::vector<uint8_t>& request)
{
    std::vector<uint8_t> response;
    if (!connected) {
        std::cerr << "Error: Not connected to serial port" << std::endl;
        return response;
    }

    // ����CRC������

    std::vector<uint8_t> requestWithCRC = addCRC(request);

    // ��ӡ����
    printHex(requestWithCRC, "TX");

    // ��������
    DWORD bytesWritten;
    if (!WriteFile(hSerial, requestWithCRC.data(), static_cast<DWORD>(requestWithCRC.size()), &bytesWritten, NULL)) {
        std::cerr << "Error: Failed to write to serial port" << std::endl;
        return response;
    }

    // ��ջ�����
    PurgeComm(hSerial, PURGE_RXCLEAR);

    // ������Ӧ
    uint8_t buffer[256];
    DWORD bytesRead;

    // ���ȶ�ȡModbus����ͷ�� (�豸ID, ������, �ֽ���)
    if (!ReadFile(hSerial, buffer, 3, &bytesRead, NULL) || bytesRead < 3) {
        std::cerr << "Error: Failed to read response header" << std::endl;
        return response;
    }

    // ���������ֽ���
    uint8_t byteCount = buffer[2];

    // ��ȡ�����ֽ� + CRC (2�ֽ�)
    if (!ReadFile(hSerial, buffer + 3, byteCount + 2, &bytesRead, NULL) || bytesRead < byteCount + 2) {
        std::cerr << "Error: Failed to read response data" << std::endl;
        return response;
    }

    // ����������Ӧ
    response.assign(buffer, buffer + 3 + byteCount + 2);

    // ��ӡ��Ӧ
    printHex(response, "RX");

    return response;
}

// ��ȡ����Ĵ��� (������ 04)
bool ModbusClient::readInputRegisters(uint8_t deviceId, uint16_t startAddress, uint16_t quantity, std::vector<uint16_t>& registers) {
    // ��ռĴ�������
    registers.clear();

    // ��������
    std::vector<uint8_t> request = {
        deviceId,                      // �豸ID
        0x04,                          // ������ (������Ĵ���)
        static_cast<uint8_t>((startAddress >> 8) & 0xFF),  // ��ʼ��ַ���ֽ�
        static_cast<uint8_t>(startAddress & 0xFF),         // ��ʼ��ַ���ֽ�
        static_cast<uint8_t>((quantity >> 8) & 0xFF),      // �Ĵ����������ֽ�
        static_cast<uint8_t>(quantity & 0xFF)              // �Ĵ����������ֽ�
    };

    // �������󲢽�����Ӧ
    std::vector<uint8_t> response = sendModbusRequest(request);

    // �����Ӧ�Ƿ���Ч
    if (response.size() < 3 + 2 * quantity + 2) {
        std::cerr << "Error: Invalid response length" << std::endl;
        return false;
    }

    // ��֤�豸ID�͹�����
    if (response[0] != deviceId || response[1] != 0x04) {
        std::cerr << "Error: Invalid response ID or function code" << std::endl;
        return false;
    }

    // ����ֽ���
    if (response[2] != 2 * quantity) {
        std::cerr << "Error: Invalid byte count" << std::endl;
        return false;
    }

    // ��֤CRC
    uint16_t responseCRC = (response[response.size() - 1] << 8) | response[response.size() - 2];
    std::vector<uint8_t> responseData(response.begin(), response.end() - 2);
    uint16_t calculatedCRC = calculateCRC(responseData);

    if (responseCRC != calculatedCRC) {
        std::cerr << "Error: CRC check failed. Got: "
            << std::hex << responseCRC << ", Expected: " << calculatedCRC << std::dec << std::endl;
        return false;
    }

    // ��ȡ�Ĵ���ֵ (ÿ���Ĵ���2�ֽ�)
    for (size_t i = 0; i < quantity; ++i) {
        uint16_t registerValue = (response[3 + i * 2] << 8) | response[4 + i * 2];
        registers.push_back(registerValue);
    }

    return true;
}

// ��ȡӦ�����ݲ�����ʵ����ֵ
double ModbusClient::readStressValue() {
    std::vector<uint16_t> registers;

    if (readInputRegisters(0x01, 0x0000, 0x0004, registers) && !registers.empty()) {
        uint16_t dataRegister = registers[0];  // ֻʹ�õ�һ��ͨ��

        // ����������ֵ (��λ: ţ)
        double stress = (dataRegister - 819) * 0.244;
        return stress;
    }

    return -999.999;  // ���ش���ֵ
}