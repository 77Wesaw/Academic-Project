#include <iostream>
#include <fstream>
#include <string>
#include "csv.h"

using namespace std;

CsvFile::CsvFile(string filename):filename(filename)
{

}

void CsvFile::Header(std::vector<string> header)
{
	ofstream writeFile(filename, ios::out);
	for (int i = 0; i < header.size(); i++)
	{
		writeFile << header[i]<<",";
	}
	
	writeFile << endl;

	writeFile.close();
}

void CsvFile::Write(std::vector<string> content)
{
	ofstream writeFile(filename, ios::app);

	for (int i = 0; i < content.size(); i++)
	{
		writeFile << content[i] << ",";
	}

	writeFile << endl;

	writeFile.close();
}