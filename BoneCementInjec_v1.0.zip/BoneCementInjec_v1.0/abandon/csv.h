#pragma once
#include <iostream>
#include <vector>

using namespace std;

class CsvFile
{
public:
	CsvFile(string filename);

	void Header(std::vector<string> header);
	void Write(std::vector<string> content);

	string filename;
};