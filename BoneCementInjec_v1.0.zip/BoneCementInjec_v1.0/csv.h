#pragma once
#include <iostream>
#include <windows.h>
#include <vector>
#include <string>
using namespace std;

class CsvFile
{
public:
	CsvFile();

	void Header(std::vector<string> header);
	void Write(std::vector<string> content);

	string filename;
};
